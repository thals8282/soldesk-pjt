<?php
$private_ip = shell_exec("ec2-metadata -o | awk '{print \$2}'");
$private_ip = trim($private_ip);
$dev_data = array('id'=>'-1','firstname'=>'Robi','lastname'=>'Tanim','username'=>'RobiTanim','password'=>'5da283a2d990e8d8512cf967df5bc0d0','last_login'=>'','date_updated'=>'','date_added'=>'');
if(!defined('base_url')) define('base_url','http://{$private_ip}/cbpos/');
if(!defined('base_app')) define('base_app', str_replace('\\','/',__DIR__).'/' );
// if(!defined('dev_data')) define('dev_data',$dev_data);
if(!defined('DB_SERVER')) define('DB_SERVER',"cosmeticdb.cbs6e2ymmkdq.ap-northeast-2.rds.amazonaws.com");
if(!defined('DB_USERNAME')) define('DB_USERNAME',"root");
if(!defined('DB_PASSWORD')) define('DB_PASSWORD',"root1234");
if(!defined('DB_NAME')) define('DB_NAME',"cbpos_db");
?>